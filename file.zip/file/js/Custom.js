   $(document).ready(function(){
  $('.clints-imgs').slick({

    dots:true,
   slidesToshow:1,
  slidesToScroll:1,
  arrows:false,
  autoplay:true,
  
  });
});